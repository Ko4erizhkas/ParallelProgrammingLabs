#include <iostream>
#include <thread>
#include <vector>
#include <random>
#include <fstream>
#include <string>
#include <math.h>

std::string primeNumbers(long long number)
{
	std::string answer = std::to_string(number) + " = ";
	int div = 2;
	while (number > 1)
	{
		while (number % div == 0)
		{
			number = number / div;
			answer += std::to_string(div) + ' ';
		}
		div++;
	}
	return answer;
}
void generateOnceFileWithRandomNumbers(std::string nameFile)
{
	std::vector<int> vec;
	vec.reserve(10000000);

	std::random_device rd;
	std::mt19937 gen(rd());
	std::uniform_int_distribution<int> dist(0, 10000);

	for (int i = 0; i < 10000000; i++)
	{
		vec.push_back(dist(gen));
	}
	std::ofstream file(nameFile, std::ios::out);
	if (file.is_open())
	{
		std::cout << "File is open\n";
		for (int num : vec)
		{
			file << num;
			file << '\n';
		}
	}
	file.close();
}
void readFile(std::string nameFile)
{
	std::string num;
	int s;
	std::ifstream from(nameFile);
	if (from.is_open())
	{
		while (from >> num)
		{
			int numb = std::stoi(num);
			std::cout << numb << std::endl;
		}
	}
	from.close();
}
void recordingFile(const std::string& nameFile)
{
	std::fstream file(nameFile);
	
	if (!file)
	{
		std::cerr << "Error opening file: " << nameFile << std::endl;
		return;
	}
	
	std::vector<std::string> info;
	std::string line;
 

 
	std::cout << "File is open\n";

	while (std::getline(file, line))
	{
		if (!line.empty())
		{
			info.push_back(line);
		}
	}


	for (auto& line : info)
	{
		try 
		{
			long long num = std::stoll(line);
			line = primeNumbers(num);
		}
		catch (std::exception& error)
		{
			std::cerr << "Error processing line: " << line << error.what() << std::endl;
		}
	}
	for (auto& i : info)
	{
		std::cout << i << std::endl;
	}
	std::cout << info.size();
}
void func(int num_threads)
{

	std::vector<std::thread> threads;
}

int main()
{
	generateOnceFileWithRandomNumbers("bla-bla-bla-ble-ble-ble-blu-blu-blu.txt");
	recordingFile("bla-bla-bla-ble-ble-ble-blu-blu-blu.txt");
	//std::cout << primeNumbers(8);
	return 0;
}